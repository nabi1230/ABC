import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TcTMasterScript extends ExtentReport
{
    @Test
    public void testCaseOne()
    {
        WebDriver driver = null;
        try
        {
            test = extent.createTest("Script : TcTMasterScript", "Test Case : testCaseOne");
            System.setProperty("webdriver.chrome.driver", "./src/main/resources/chromedriver.exe");
            driver = new ChromeDriver();
            driver.get("https://demo.midtrans.com");
            driver.manage().window().maximize();
            HomePage.clickBuyNowButton(driver);
            HomePage.enterName(driver, "Syed Ali");
            HomePage.enterEmail(driver, "abcdef@jhi.com");
            HomePage.enterPhoneNumber(driver,"1234567890");
            HomePage.enterCity(driver, "Englewood");
            HomePage.enterAddress(driver, "3594 S Broadway, Englewood, Parker Road");
            HomePage.enterPostalCode(driver, "80113");
            HomePage.clickCheckoutButton(driver);
            //System.out.println(driver.findElements(By.tagName("iFrame")).size());
            Common.switchToFrameByNameOrId(driver, "snap-midtrans");
            OrderSummary.clickContinueButton(driver);
            OrderSummary.clickPaymentMethod(driver, "Credit Card");
            OrderSummary.enterCardNumber(driver, "4811111111111114");
            OrderSummary.enterExpiryDate(driver, "0220");
            OrderSummary.enterCVV(driver, "123");
            OrderSummary.clickPayNowButton(driver);
            Common.switchToFrameByIndex(driver, 0);
            Common.sleep(10000);
            OrderSummary.enterPassword(driver, "112233");
            OrderSummary.clickOKButton(driver);
            OrderSummary.verifySuccessMessage(driver);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail();
        }
        finally
        {
            driver.close();
            driver.quit();
        }
    }
}