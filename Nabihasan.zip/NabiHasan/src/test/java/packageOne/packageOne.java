package packageOne;

import org.testng.annotations.Test;

public class packageOne
{
    @Test
    public static void methodOne()
    {
        System.out.println("This is method one");
    }

    @Test
    public static void methodTwo()
    {
        System.out.println("This is method two");
    }
}