import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentReport
{
    ExtentReports extent;
    ExtentHtmlReporter htmlReporter;
    static ExtentTest test;

    @BeforeClass
    public void startReport()
    {
        DateFormat dateFormat = new SimpleDateFormat("ddMMMMyyyy_HHmmss");
        Date date = new Date();
        String reportName = (dateFormat.format(date));
        htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")+"/test-report/ExtentReport_"+reportName+".html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        extent.setSystemInfo("Host Name", "Syed Arsalan Ali");
        extent.setSystemInfo("Operating System", "Microsoft Windows 10");
        extent.setSystemInfo("Environment", "Home Environment");
    }

    /*@BeforeTest
    public void startReport()//Original
    {
        DateFormat dateFormat = new SimpleDateFormat("ddMMMMyyyy_HHmmss");
        Date date = new Date();
        String reportName = (dateFormat.format(date));
        htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")+"/test-report/ExtentReport_"+reportName+".html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        extent.setSystemInfo("Host Name", "Syed Arsalan Ali");
        extent.setSystemInfo("Operating System", "Microsoft Windows 10");
        extent.setSystemInfo("Environment", "Home Environment");
    }*/
/*
    @Test
    public void testPass()
    {
        test = extent.createTest("testPass", "This Test Case Is Passed");
        Assert.assertTrue(true);
    }

    @Test
    public void testFail()
    {
        test = extent.createTest("testFail", "This Test Case Is Failed");
        Assert.assertTrue(false);
    }

    @Test
    public void testSkip()
    {
        test = extent.createTest("testSkip", "This Test Case Is Skipped");
        throw new SkipException("This Test Case Is Skipped");
    }

    @AfterMethod
    public void getResult(ITestResult result)
    {
        if(result.getStatus() == ITestResult.FAILURE)
        {
            test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " Test Case Failed Due To Below Issue : ", ExtentColor.RED));
            test.fail(result.getThrowable());
        }
        else if(result.getStatus() == ITestResult.SUCCESS)
        {
            test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " Test Case Passed", ExtentColor.GREEN));
        }
        else
        {
            test.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + " Test Case Skipped", ExtentColor.YELLOW));
            test.skip(result.getThrowable());
        }
    }
*/

    @AfterSuite
    public synchronized void endReport()

    {
        extent.flush();
    }

    /*@AfterTest
    public void endReport()//Original

    {
        extent.flush();
    }*/
}