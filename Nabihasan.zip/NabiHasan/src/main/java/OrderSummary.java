import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class OrderSummary extends ExtentReport
{
    public static void clickContinueButton(WebDriver driver)
    {
        String xpath = "//a[div[span[text()='Continue']]]";
        WebElement element = Common.explicitWait(driver, xpath,"Continue button", "clickable");
        element.click();
        test.log(Status.PASS, "Continue button clicked successfully");
    }

    public static void clickPaymentMethod(WebDriver driver, String paymentMethodName)
    {
        String xpath = "//div[@id='payment-list']/div/a/div[@class='list-content']/div[text()='"+paymentMethodName+"']";
        WebElement element = Common.explicitWait(driver, xpath, paymentMethodName+" payment method", "clickable");
        element.click();
        test.log(Status.PASS, paymentMethodName+" payment method button clicked successfully");
    }

    public static void enterCardNumber(WebDriver driver, String cardNumber)
    {
        String xpath = "//input[following-sibling::label[text()='Card number']]";
        WebElement element = Common.explicitWait(driver, xpath, "Card Number field", "clickable");
        element.sendKeys(cardNumber);
        test.log(Status.PASS, "Card Number: "+cardNumber+" entered successfully");
    }

    public static void enterExpiryDate(WebDriver driver, String expiryDate)
    {
        String xpath = "//input[following-sibling::label[text()='Expiry date']]";
        WebElement element = Common.explicitWait(driver, xpath, "Expiry Date field", "clickable");
        element.sendKeys(expiryDate);
        test.log(Status.PASS, "Expiry Date: "+expiryDate+" entered successfully");
    }

    public static void enterCVV(WebDriver driver, String CVV)
    {
        String xpath = "//input[following-sibling::label[text()='CVV']]";
        WebElement element = Common.explicitWait(driver, xpath, "CVV field", "clickable");
        element.sendKeys(CVV);
        test.log(Status.PASS, "CVV: "+CVV+" entered successfully");
    }

    public static void clickPayNowButton(WebDriver driver)
    {
        String xpath = "//a[div[span[text()='Pay Now']]]";
        WebElement element = Common.explicitWait(driver, xpath,"Pay Now button", "clickable");
        element.click();
        test.log(Status.PASS, "Pay Now button clicked successfully");
    }

    public static void enterPassword(WebDriver driver, String password)
    {
        String xpath = "//label[text()='Password:']/following-sibling::div/input";
        WebElement element = Common.explicitWait(driver, xpath, "Password field", "clickable");
        element.click();
        element.sendKeys(password);
        test.log(Status.PASS, "Password: "+password+" entered successfully");
    }

    public static void clickOKButton(WebDriver driver)
    {
        String xpath = "//button[text()='OK']";
        WebElement element = Common.explicitWait(driver, xpath, "OK button", "clickable");
        element.click();
        test.log(Status.PASS, "OK button clicked successfully");
    }

    public static void verifySuccessMessage(WebDriver driver)
    {
        String xpath1 = "//span[text()='Thank you for your purchase.']";
        String xpath2 = "//span[text()='Get a nice sleep.']";
        Common.explicitWait(driver, xpath1, "Success message: \"Thank you for your purchase.\"", "visible");
        Common.explicitWait(driver, xpath1, "Success message: \"Get a nice sleep.\"", "visible");
    }
}