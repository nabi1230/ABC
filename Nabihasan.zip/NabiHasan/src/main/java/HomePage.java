import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage extends ExtentReport
{
    public static void clickBuyNowButton(WebDriver driver)
    {
        String xpath = "//a[text()='BUY NOW']";
        WebElement element = Common.explicitWait(driver, xpath, "Buy Now button", "clickable");
        element.click();
        test.log(Status.PASS, "Buy Now button is clicked successfully");
    }

    public static void enterName(WebDriver driver, String name)
    {
        String xpath = "//td[text()='Name']/following-sibling::td/input";
        WebElement element = Common.explicitWait(driver, xpath, "Name input field", "clickable");
        element.clear();
        element.sendKeys(name);
        test.log(Status.PASS, "Name: "+name+" entered successfully");
    }

    public static void enterEmail(WebDriver driver, String email)
    {
        String xpath = "//td[text()='Email']/following-sibling::td/input";
        WebElement element = Common.explicitWait(driver, xpath, "Email input field", "clickable");
        element.clear();
        element.sendKeys(email);
        test.log(Status.PASS, "Email: "+email+" entered successfully");
    }

    public static void enterPhoneNumber(WebDriver driver, String phoneNumber)
    {
        String xpath = "//td[text()='Phone no']/following-sibling::td/input";
        WebElement element = Common.explicitWait(driver, xpath, "Phone Number input field", "clickable");
        element.clear();
        element.sendKeys(phoneNumber);
        test.log(Status.PASS, "Phone Number: "+phoneNumber+" entered successfully");
    }

    public static void enterCity(WebDriver driver, String city)
    {
        String xpath = "//td[text()='City']/following-sibling::td/input";
        WebElement element = Common.explicitWait(driver, xpath, "City input field", "clickable");
        element.clear();
        element.sendKeys(city);
        test.log(Status.PASS, "City: "+city+" entered successfully");
    }

    public static void enterAddress(WebDriver driver, String address)
    {
        String xpath = "//td[text()='Address']/following-sibling::td/textarea";
        WebElement element = Common.explicitWait(driver, xpath, "Address input field", "clickable");
        element.clear();
        element.sendKeys(address);
        test.log(Status.PASS, "Address: "+address+" entered successfully");
    }

    public static void enterPostalCode(WebDriver driver, String postalCode)
    {
        String xpath = "//td[text()='Postal Code']/following-sibling::td/input";
        WebElement element = Common.explicitWait(driver, xpath, "Postal Code input field", "clickable");
        element.clear();
        element.sendKeys(postalCode);
        test.log(Status.PASS, "Postal Code: "+postalCode+" entered successfully");
    }

    public static void clickCheckoutButton(WebDriver driver)
    {
        String xpath = "//div[text()='CHECKOUT']";
        WebElement element = Common.explicitWait(driver, xpath, "Checkout button", "clickable");
        element.click();
        test.log(Status.PASS, "Checkout button clicked successfully");
    }
}