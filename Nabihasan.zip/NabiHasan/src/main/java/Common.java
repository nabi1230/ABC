import com.aventstack.extentreports.Status;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.File;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

public class Common extends ExtentReport
{
    public static WebElement explicitWait(WebDriver driver, String xpath, String elementName, String waitTill)
    {
        WebElement element = null;
        try
        {
            WebDriverWait wait = new WebDriverWait(driver, 30);
            if (waitTill.equals("clickable")) {
                element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
                test.log(Status.PASS, elementName + " is located successfully");
            } else if (waitTill.equals("visible")) {
                element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
                test.log(Status.PASS, elementName + " is located successfully");
            } else if (waitTill.equals("present")) {
                element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
                test.log(Status.PASS, elementName + " is located successfully");
            } else {
                test.log(Status.FAIL, "Wait till condition is not valid");
            }
        }
        catch(Exception e)
        {
            test.log(Status.FAIL, elementName + " is not located");
            e.printStackTrace();
            Assert.fail();
        }
        return element;
    }

    public static void sleep(int time)
    {
        try
        {
            Thread.sleep(time);
            test.log(Status.PASS, "Thread sleep for " + time + " milliseconds");
        }
        catch(Exception e)
        {
            test.log(Status.FAIL, "Thread sleep failed");
            e.printStackTrace();
            Assert.fail();
        }
    }

    public static void takeScreenshot(WebDriver driver, String fileDestinationPath)
    {
        try
        {
            TakesScreenshot screenshot = ((TakesScreenshot)driver);
            File screenshotFile = screenshot.getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshotFile, new File(fileDestinationPath));
            test.log(Status.PASS, "Screenshot saved at location: " + fileDestinationPath);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Assert.fail();
            test.log(Status.FAIL, "Unable to take screenshot");
        }
    }

    public static void switchToFrameByNameOrId(WebDriver driver, String frameName)
    {
        driver.switchTo().frame(frameName);
        test.log(Status.PASS, "Switched to frame: "+frameName);
    }

    public static void switchToFrameByIndex(WebDriver driver, int frameIndex)
    {
        driver.switchTo().frame(frameIndex);
        test.log(Status.PASS, "Switched to frame at index: "+frameIndex);
    }

    public static void switchToDefaultContent(WebDriver driver)
    {
        driver.switchTo().defaultContent();
        test.log(Status.PASS, "Switched to default content");
    }
}